//Encapsulating coordinates of a cell

class Coordinates{
    public int x;
    public int y;
    public Coordinates(int xp, int py){
        x=xp;
        y=py;
    }
}